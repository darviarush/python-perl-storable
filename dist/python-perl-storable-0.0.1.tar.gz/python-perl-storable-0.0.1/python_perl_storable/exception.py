class PerlStorableException(Exception):
    pass
